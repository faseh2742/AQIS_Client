<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="{{asset('assets/css/lib/bootstrap.min.css')}}" rel="stylesheet">

    <!-- Styles -->
    {{-- <link href="{{ asset('css/app.css') }}" rel="stylesheet"> --}}
    <style>

        .form-handler{
            border-radius: 35px;
            box-shadow: inset 0px 0px 0px 4px hsl(0, 0%, 77%);
            background: rgb(255, 255, 255);
        }
        input[type=text]{
         border: 2px solid rgb(240, 236, 236);
          border-radius: 10px;
        }
        input[type=password]{
         border: 2px solid rgb(240, 236, 236);
          border-radius: 10px;
        }
        label{
          font-size: 16px;
          font-weight: bolder;
        }
        </style>
</head>
<body>


<div class="row border">
    <div class="col-md-12 border">
      <nav
        class="navbar navbar-expand-sm navbar-dark justify-content-around p-3"
      >
        <!-- Brand -->
        <a class="navbar-brand" href="#">Logo</a>
        <!-- Links -->
        <ul class="navbar-nav">
          <li class="nav-item p-2 pl-5">
            <a class="nav-link text-dark font-weight-bolder" href="#">Tours</a>
          </li>
          <li class="nav-item p-2 pl-5">
            <a class="nav-link text-dark font-weight-bolder" href="#"
              >Products</a
            >
          </li>
          <li class="nav-item p-2 pl-5">
            <a class="nav-link text-dark font-weight-bolder" href="#"
              >Pricing</a
            >
          </li>
          <li class="nav-item p-2 pl-5">
            <a class="nav-link text-dark font-weight-bolder" href="#"
              >Contacts</a
            >
          </li>
        </ul>
        <ul>

        {{-- <button class="btn btn-dark" href="#">Sign Up</button> --}}

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto">
            <!-- Authentication Links -->
            @guest
                @if (Route::has('login'))
                    <li class="nav-item">
                        <a class="btn btn-default" href="{{ route('login') }}">{{ __('Login') }}</a>
                    </li>
                @endif

                @if (Route::has('register'))
                    <li class="nav-item">
                        <a class="btn btn-dark" href="{{ route('register') }}">{{ __('Register') }}</a>
                    </li>
                @endif
            @else
                <li class="nav-item dropdown bg-dark">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        {{ Auth::user()->name }}
                    </a>

                    <div class="dropdown-menu dropdown-menu-end " aria-labelledby="navbarDropdown">
                        <a class="dropdown-item " href="{{ route('logout') }}"
                           onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                            {{ __('Logout') }}
                        </a>

                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                            @csrf
                        </form>
                    </div>
                </li>
            @endguest
        </ul>
        </div>
      </nav>
    </div>

    @yield('content')
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</div>

</body>
