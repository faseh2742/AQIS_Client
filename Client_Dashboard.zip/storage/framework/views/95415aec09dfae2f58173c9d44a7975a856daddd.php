<?php $__env->startSection('title', 'employeement'); ?>
<?php $__env->startSection('heading', 'employeement'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <?php $__currentLoopData = App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <div class="card-header bg-secondary" id="heading<?php echo e($category->id); ?>">
                <h5 class="mb-0">
                    <button class="btn btn-light collapsed" data-toggle="collapse" data-target="#collapse<?php echo e($category->id); ?>"
                        aria-expanded="false" aria-controls="collapse<?php echo e($category->id); ?>">
                       <?php echo e($category->name); ?>

                    </button>
                    <a href='#' class="btn btn-primary float-right" data-toggle="modal" data-target="#outcomeModel<?php echo e($category->id); ?>">Add <i
                        class="fa fa-plus"></i></a>
                </h5>
            </div>
            <div id="collapse<?php echo e($category->id); ?>" class="collapse" aria-labelledby="heading<?php echo e($category->id); ?>" data-parent="#accordion">
                <div class="card">

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>

                                        <th>Outcome</th>
                                        <th>Status</th>
                                        <th>Notes</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = App\Models\ClientOutcome::with('outcome')->where(['client_id'=>3432,'category_id'=>$category->id])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outcome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td><?php echo e($outcome->outcome->outcome); ?></td>
                                        <td><?php echo e($outcome->status); ?></td>
                                        <td><?php echo e($outcome->notes); ?></td>

                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade " id="outcomeModel<?php echo e($category->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e($category->name); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('Outcome.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">


                        <div class="form-group">
                            <label>Outcome</label>
                            <input type="hidden" name="category_id" value="<?php echo e($category->id); ?>">
                            <select class="form-control"  name="outcome_id">
                                <?php $__currentLoopData = App\Models\Outcome::where('category_id',$category->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->id); ?>" ><?php echo e($row->outcome); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                        <select class="form-control" name="status">
                            <?php
                                $eduDropdown = App\Models\Dropdown::with('items')
                                    ->where('name', 'Outcome Status')
                                    ->first();
                            ?>
                            <?php $__currentLoopData = $eduDropdown->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->item); ?>"><?php echo e($row->item); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                        </div>
                        <div class="form-group">
                            <label>Notes</label>
                            <input type="text" class="form-control"
                                placeholder="Notes" name="notes" required
                              >
                        </div>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add</button>

                    </div>
                </form>
            </div>
        </div>

    </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Client\resources\views/user/outcome.blade.php ENDPATH**/ ?>