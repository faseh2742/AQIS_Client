<?php $__env->startSection('title', 'Meetings'); ?>
<?php $__env->startSection('heading', 'My Meetings'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
      <div class="card">
          <div class="card-title">
              <h4>Upcoming Meetings </h4>

          </div>
          <div class="card-body">
              <div class="table-responsive">
                  <table class="table">
                      <thead>
                          <tr>
                              <th>Program</th>
                              <th>Service</th>
                              <th>Medium</th>
                              <th>Location</th>
                              <th>Staff</th>
                               <th>Status</th>
                              <th>Action</th>
                          </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $upcomingmeetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                          <tr>

                              <td><?php echo e($row->programName); ?></td>
                              <td><?php echo e($row->serviceProvided); ?></td>
                              <td ><?php echo e($row->serviceDelivery); ?></td>

                              <td ><?php echo e($row->location); ?></td>
                              <td ><?php echo e($row->staff->user->firstName); ?></td>
                              <td>

                                <?php if($row->status=='Client Cancelled'): ?>
                                <span class="badge badge-danger"><?php echo e($row->status); ?></span>
                                <?php elseif($row->status=='No Show'): ?>
                                <span class=
                                "badge badge-info"><?php echo e($row->status); ?></span>
                                <?php elseif($row->status=='Rejected'): ?>
                                <span class="badge badge-dark"><?php echo e($row->status); ?></span>
                                <?php endif; ?>
                               </td>
                              <td >
                                <?php if($row->meetingLink): ?>
                                <a href="<?php echo e($row->meetingLink); ?>" class="btn btn-success" target="_blank">Join</a>
                                <?php endif; ?>
                            </td>

                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      </tbody>
                  </table>
              </div>
          </div>
      </div>
    </div>
</div>
  <div class="row">
      <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h4>Past Meetings </h4>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Program</th>
                                <th>Service</th>
                                <th>Medium</th>
                                <th>Location</th>
                                <th>Staff</th>
                                <th>Status</th>
                                <th>Feedback</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $pastmeetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <tr>

                                <td><?php echo e($row->programName); ?></td>
                                <td><?php echo e($row->serviceProvided); ?></td>
                                <td ><?php echo e($row->serviceDelivery); ?></td>

                                <td ><?php echo e($row->location); ?></td>
                                <td ><?php echo e($row->staff->user->firstName); ?></td>
                                <td>
                                    <?php if($row->status=='Client Cancelled'): ?>
                                    <span class="badge badge-danger"><?php echo e($row->status); ?></span>
                                    <?php elseif($row->status=='No Show'): ?>
                                    <span class="badge badge-info"><?php echo e($row->status); ?></span>
                                    <?php elseif($row->status=='Rejected'): ?>
                                    <span class="badge badge-dark"><?php echo e($row->status); ?></span>
                                    <?php elseif($row->status=='Attended'): ?>
                                    <span class="badge badge-success"><?php echo e($row->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('Meetings.show',$row->id)); ?>" class="btn btn-warning btn-sm">Feedback <i class="fa fa-comments-o" aria-hidden="true"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Client\resources\views/meeting/index.blade.php ENDPATH**/ ?>