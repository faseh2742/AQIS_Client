<div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
    <div class="nano">
        <div class="nano-content">
            <div class="logo">
                <a href="index.html">
                    <!-- <img src="assets/images/logo.png" alt="" /> -->
                    <span>AQIS</span>
                </a>
            </div>
            <ul>
                <li class="label">Main</li>
                <li>
                    <a href="<?php echo e(url('/Client')); ?>">
                        <i class="ti-home"></i> Dashboard</a>
                </li>
                <li class="label">Navigate</li>
                <li>
                    <a class="sidebar-sub-toggle">
                        <i class="ti-user"></i> Profile
                        <span class="sidebar-collapse-icon ti-angle-down"></span>
                    </a>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('Clients.index')); ?>"> <i class="ti-user"></i> Profile</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('Education.index')); ?>"> <i class="ti-bag"></i> Education</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('Employeement.index')); ?>"> <i class="ti-briefcase"></i> Employeement</a>
                        </li>
                        
                        <li>
                            <a href="<?php echo e(route('Training.index')); ?>"> <i class="ti-blackboard"></i>Training</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('Outcome.index')); ?>"> <i class="ti-check-box"></i>Outcomes</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('Document.index')); ?>"> <i class="ti-file"></i>Documents</a>
                        </li>
                    </ul>

                </li>
                <li>
                    <a href="<?php echo e(route('Meetings.index')); ?>">
                        <i class="ti-bookmark"></i> My Meetings</a>
                </li>
                <li>
                    <a href="<?php echo e(route('Events.index')); ?>">
                        <i class="ti-calendar"></i> My Events</a>
                </li>


                <li>
                    <a>
                        <i class="ti-close"></i> Logout</a>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH E:\Client\resources\views/layouts/sidenav.blade.php ENDPATH**/ ?>