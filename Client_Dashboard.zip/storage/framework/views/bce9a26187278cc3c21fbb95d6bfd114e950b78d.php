<?php $__env->startSection('title', 'Events / Calander'); ?>
<?php $__env->startSection('heading', 'Events / Calander'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-title">
                    <h4>Events Calendar</h4>
                </div>
                <div class="card-body">
                    <div class="row">

                        <div class="col-md-12">
                            <div class="card-box">
                                <div id="calendar"></div>
                            </div>
                        </div>
                        <!-- end col -->

                    </div>
                </div>
            </div>
            <!-- /# card -->
        </div>
        <!-- /# column -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/lib/calendar/fullcalendar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/calendar/fullcalendar-init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        var myCalendar = $('#calendar');
        myCalendar.fullCalendar();



        document.addEventListener('DOMContentLoaded', function() {

            $.get("<?php echo e(route('Events.getEvents')); ?>")
                .then(function(response) {
                    console.log(new Date());
                    response.forEach(element => {


                        var myEvent = {
                            title: element.title,
                            allDay: true,
                            start: new Date(),
                            end: new Date(),
                            backgroundColor:element.backgroundColor,
                            borderColor:element.borderColor,
                            textColor:element.textColor,

                        };
                        console.log(new Date());
                        console.log(new Date(element.start));
                        myCalendar.fullCalendar('renderEvent', myEvent);
                    });


                });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Client\resources\views/event/calander.blade.php ENDPATH**/ ?>