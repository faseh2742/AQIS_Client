<?php $__env->startSection('title', 'Events'); ?>
<?php $__env->startSection('heading', 'Events'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
      <div class="card">
          <div class="card-title">
              <h4>Upcoming Events </h4>

          </div>
          <div class="card-body">
              <div class="">
                  <table class="table table-responsive">
                      <thead>
                          <tr>

                              <th>Title</th>
                              <th>Service Type</th>
                              <th>Program</th>
                              <th>Location</th>
                              <th>Start</th>
                              <th>End</th>
                              <th>Action</th>

                          </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                          <tr>

                              <td><?php echo e($row->title); ?></td>
                              <td><?php echo e($row->serviceDelivery); ?></td>
                              <td>
                                <?php if($row->groupActivity): ?>
                                <?php echo e($row->groupActivity->programName); ?>

                                <?php endif; ?>

                            </td>
                              <td>  <?php if($row->groupActivity): ?>
                                <?php echo e($row->groupActivity->location); ?>

                                <?php endif; ?></td>
                              <td><?php echo e($row->start); ?></td>
                              <td><?php echo e($row->end); ?></td>
                              <td>
                                <form action="<?php echo e(route('Events.RegisterClient')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($row->id); ?>">
                                <button class="btn btn-primary btn-sm ">Register</button>
                                </form>
                            </td>
                          </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      </tbody>
                      <tfoot>
                        <th colspan="6"></th>
                        <th><a href="<?php echo e(route('Events.calander')); ?>" class="btn btn-success float-right">View All</a></th>
                      </tfoot>
                  </table>


              </div>
          </div>
      </div>
    </div>
</div>
  <div class="row">
      <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h4>My Events </h4>

            </div>
            <div class="card-body">
                <div class="">
                    <table class="table table-responsive">
                        <thead>
                            <tr>

                                <th>Title</th>
                                <th>Service Type</th>
                                <th>Program</th>
                                <th>Location</th>
                                <th>Start</th>
                                <th>End</th>
                                <th>Action</th>

                            </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $myEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <tr>

                                <td><?php echo e($row->title); ?></td>
                                <td><?php echo e($row->serviceDelivery); ?></td>
                                <td><?php echo e($row->groupActivity->programName); ?></td>
                                <td><?php echo e($row->groupActivity->location); ?></td>
                                <td><?php echo e($row->start); ?></td>
                                <td><?php echo e($row->end); ?></td>
                                <td >
                                      <form action="<?php echo e(route('Events.UnRegisterClient')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($row->id); ?>">
                                <button class="btn btn-danger btn-sm">Un Register</button>
                                </form>
                                  </td>
                            </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>


                </div>
            </div>
        </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function(){

        $('.table').DataTable( {
  "autoWidth": false
});

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Client\resources\views/event/index.blade.php ENDPATH**/ ?>