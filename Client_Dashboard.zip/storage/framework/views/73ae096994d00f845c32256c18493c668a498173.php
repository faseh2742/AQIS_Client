<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>AQIS Client- <?php echo $__env->yieldContent('title'); ?></title>

    <!-- ================= Favicon ================== -->
    <!-- Standard -->
    <link rel="shortcut icon" href="http://placehold.it/64.png/000/fff">
    <!-- Retina iPad Touch Icon-->
    <link rel="apple-touch-icon" sizes="144x144" href="http://placehold.it/144.png/000/fff">
    <!-- Retina iPhone Touch Icon-->
    <link rel="apple-touch-icon" sizes="114x114" href="http://placehold.it/114.png/000/fff">
    <!-- Standard iPad Touch Icon-->
    <link rel="apple-touch-icon" sizes="72x72" href="http://placehold.it/72.png/000/fff">
    <!-- Standard iPhone Touch Icon-->
    <link rel="apple-touch-icon" sizes="57x57" href="http://placehold.it/57.png/000/fff">

    <!-- Toastr -->
    <link href="<?php echo e(asset('assets/css/lib/toastr/toastr.min.css')); ?>" rel="stylesheet">
    <!-- Sweet Alert -->
    <link href="<?php echo e(asset('assets/css/lib/sweetalert/sweetalert.css')); ?>" rel="stylesheet">
    <!-- Range Slider -->
    <link href="<?php echo e(asset('assets/css/lib/rangSlider/ion.rangeSlider.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/lib/rangSlider/ion.rangeSlider.skinFlat.css')); ?>" rel="stylesheet">
    <!-- Bar Rating -->
    <link href="<?php echo e(asset('assets/css/lib/barRating/barRating.css')); ?>" rel="stylesheet">
    <!-- Nestable -->
    <link href="<?php echo e(asset('assets/css/lib/nestable/nestable.css')); ?>" rel="stylesheet">
    <!-- JsGrid -->
    <link href="<?php echo e(asset('assets/css/lib/jsgrid/jsgrid-theme.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/lib/jsgrid/jsgrid.min.css')); ?>" type="text/css" rel="stylesheet" />
    <!-- Datatable -->
    <link href="<?php echo e(asset('assets/css/lib/datatable/dataTables.bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/lib/data-table/buttons.bootstrap.min.css')); ?>" rel="stylesheet" />
    <!-- Calender 2 -->
    
    <!-- Weather Icon -->
    <link href="<?php echo e(asset('assets/css/lib/weather-icons.css')); ?>" rel="stylesheet" />
    <!-- Owl Carousel -->
    <link href="<?php echo e(asset('assets/css/lib/owl.carousel.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/lib/owl.theme.default.min.css')); ?>" rel="stylesheet" />
    <!-- Select2 -->
    <link href="<?php echo e(asset('assets/css/lib/select2/select2.min.css')); ?>" rel="stylesheet">
    <!-- Chartist -->
    <link href="<?php echo e(asset('assets/css/lib/chartist/chartist.min.css')); ?>" rel="stylesheet">
    <!-- Calender -->
    <link href="<?php echo e(asset('assets/css/lib/calendar/fullcalendar.css')); ?>" rel="stylesheet" />

    <!-- Common -->
    <link href="<?php echo e(asset('assets/css/lib/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/lib/themify-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/lib/menubar/sidebar.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/lib/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/lib/helper.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

</head>

<body>
    <?php echo $__env->make('layouts.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- /# sidebar -->


 <?php echo $__env->make('layouts.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 p-r-0 title-margin-right">
                        <div class="page-header">
                            <div class="page-title">

                                <h1 class="text-info"> <?php echo $__env->yieldContent('heading'); ?>
                                </h1>
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->

                    <!-- /# column -->
                </div>
                <!-- /# row -->
                <section id="main-content">
                    <div class="row">
                        <div class="col-lg-12">
                            <?php echo $__env->yieldContent('content'); ?>

                        </div>
                    </div>

                </section>

            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer">
                        <p><?php echo e(date('Y')); ?> © AQIS. -
                            <a href="#">aqis.com</a>
                        </p>
                    </div>
                </div>

            </div>
        </div>
    </div>




    <!-- Common -->

    <script src="<?php echo e(asset('assets/js/lib/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/jquery.nanoscroller.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/menubar/sidebar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/preloader/pace.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>

    <!-- Calender -->
    <script src="<?php echo e(asset('assets/js/lib/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/moment/moment.js')); ?>"></script>


    <!--  Flot Chart -->
    

    <!--  Chartist -->
    

    <!--  Chartjs -->
    

    <!--  Knob -->
    

    <!--  Morris -->
    

    <!--  Peity -->
    

    <!--  Sparkline -->
    

    <!-- Select2 -->
    

    <!--  Validation -->
    <script src="<?php echo e(asset('assets/js/lib/form-validation/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/form-validation/jquery.validate-init.js')); ?>"></script>

    <!--  Circle Progress -->
    

    <!--  Vector Map -->
    

    <!--  Simple Weather -->
    

    <!--  Owl Carousel -->
    <script src="<?php echo e(asset('assets/js/lib/owl-carousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/owl-carousel/owl.carousel-init.js')); ?>"></script>

    <!--  Calender 2 -->
    


    <!-- Datatable -->
    <script src="<?php echo e(asset('assets/js/lib/data-table/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/buttons.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/buttons.flash.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/data-table/datatables-init.js')); ?>"></script>

    <!-- JS Grid -->
    

    <!--  Datamap -->
    

    <!--  Nestable -->
    

    <!--ION Range Slider JS-->
    

    <!-- Bar Rating-->
    

    <!-- jRate -->
    

    <!-- Sweet Alert -->
    <script src="<?php echo e(asset('assets/js/lib/sweetalert/sweetalert.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/sweetalert/sweetalert.init.js')); ?>"></script>

    <!-- Toastr -->
    
    

    <script>
    <?php if(Session::has('message')): ?>
    swal("Success!", "<?php echo e(session('message')); ?>", "success");

    <?php endif; ?>
    <?php if(Session::has('error')): ?>
    swal("Error !", "<?php echo e(session('error')); ?>", "error");
    <?php endif; ?>
    <?php if(Session::has('info')): ?>
    swal("Error !", "<?php echo e(session('info')); ?>", "info");
    <?php endif; ?>

    </script>



























    <!--  Dashboard 1 -->
    <script src="<?php echo e(asset('assets/js/dashboard1.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dashboard2.js')); ?>"></script>

    <?php echo $__env->yieldContent('scripts'); ?>
    <?php echo $__env->yieldContent('script'); ?>

</body>

</html>
<?php /**PATH E:\Client\resources\views/layouts/master.blade.php ENDPATH**/ ?>