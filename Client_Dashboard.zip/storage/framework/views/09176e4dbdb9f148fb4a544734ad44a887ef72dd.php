<?php $__env->startSection('title', 'Education'); ?>
<?php $__env->startSection('heading', 'Education'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-title">
                    <h4>My Educations</h4>
                    <a href='#' class="btn btn-primary float-right" data-toggle="modal" data-target="#educationModel">Add
                        <i class="fa fa-plus"></i></a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Education Level</th>
                                    <th>Major</th>
                                    <th>Graduation Year</th>
                                    <th>Country</th>
                                    <th>Highest</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $myEducation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td><?php echo e($education->education_level); ?></td>
                                        <td><?php echo e($education->major); ?></td>
                                        <td><?php echo e($education->graduation_date); ?></td>
                                        <td><?php echo e($education->education_country); ?></td>
                                        <td>

                                            <?php if(4259 == $education->id): ?>
                                                <div class="badge badge-warning">
                                                    Highest
                                                </div>

                                            <?php else: ?>
                                                <form action="<?php echo e(route('Education.setHigh')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="id" value="<?php echo e($education->id); ?>">
                                                    <button class="btn btn-sm btn-success" type="submit">Set High <i
                                                            class="fa fa-plus"></i></button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="row float-right">

                                                <div class="col-sm-3">
                                                    <form id="deleteEducationForm<?php echo e($education->id); ?>"
                                                        action="<?php echo e(route('Education.destroy', $education->id)); ?>"
                                                        method="POST">
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <button class="btn btn-danger btn-sm" type="button"
                                                            onclick="javascript:(confirm('Do you want to delete ?'))?
                                                document.getElementById('deleteEducationForm<?php echo e($education->id); ?>').submit():'' "><i
                                                                class="fa fa-trash"></i></button>
                                                    </form>
                                                </div>
                                                <div class="col-sm-3">
                                                    <a href="javascript:;" class="btn btn-info btn-sm"
                                                        data-toggle="modal"
                                                        data-target="#educationModelEdit<?php echo e($education->id); ?>"><i
                                                            class="fa fa-edit"></i>
                                                    </a>
                                                </div>
                                             </div>




                                        </td>

                                    </tr>

                                    <div class="modal fade" id="educationModelEdit<?php echo e($education->id); ?>" tabindex="-1"
                                        role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                        <form action="<?php echo e(route('Education.update', $education->id)); ?>" method="POST">
                                            <?php echo method_field('PUT'); ?>
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-dialog modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalCenterTitle">Edit
                                                            <?php echo e($education->major); ?></h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>

                                                    <div class="modal-body">

                                                        <div class="form-group">
                                                            <label>Level Of Education</label>
                                                            <input type="hidden" name="id"
                                                                value="<?php echo e($education->id); ?>">
                                                            <select class="form-control" name="education_level">
                                                                <?php
                                                                    $eduDropdown = App\Models\Dropdown::with('items')
                                                                        ->where('name', 'Level of Education')
                                                                        ->first();
                                                                ?>
                                                                <?php $__currentLoopData = $eduDropdown->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($row->item); ?>" <?php echo e(($row->item == $education->education_level)?"selected":""); ?>>
                                                                        <?php echo e($row->item); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Country</label>
                                                            <select class="form-control" name="education_country">
                                                                <?php $__currentLoopData = App\Models\Country::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($row->name); ?>"
                                                                        <?php echo e(($row->name == $education->education_country)?"selected":""); ?>>
                                                                        <?php echo e($row->name); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Major</label>
                                                            <input type="text" name="major" class="form-control"
                                                                placeholder="Major" value="<?php echo e($education->major); ?>" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Graduation Year</label>
                                                            <input type="text" class="form-control"
                                                                placeholder="Graduation Year" name="graduation_date"
                                                                value="<?php echo e($education->graduation_date); ?>" required>
                                                        </div>



                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-success">Update</button>

                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade " id="educationModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Add Education</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('Education.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">

                        <div class="form-group">
                            <label>Level Of Education</label>
                            <select class="form-control" name="education_level">
                                <?php
                                    $eduDropdown = App\Models\Dropdown::with('items')
                                        ->where('name', 'Level of Education')
                                        ->first();
                                ?>
                                <?php $__currentLoopData = $eduDropdown->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->item); ?>"><?php echo e($row->item); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                        <div class="form-group">
                            <label>Country</label>
                            <select class="form-control" name="education_country">
                                <?php $__currentLoopData = App\Models\Country::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->name); ?>"
                                        <?php echo e($row->name == $education->education_country); ?>>
                                        <?php echo e($row->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                        <div class="form-group">
                            <label>Major</label>
                            <input type="text" class="form-control" placeholder="Major" name="major" required>
                        </div>
                        <div class="form-group">
                            <label>Graduation Year</label>
                            <input type="text" class="form-control" placeholder="Graduation Year"
                                name="graduation_date" required>
                        </div>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add</button>

                    </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        function delete(e) {
            confirm('Do you want to delete ?');

            //    if(confirm('Do you want to delete ?')){
            //     $('form[name=deleteEducation]').submit();
            //    }
            //    else{
            //     e.preventDefault();
            //    }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Client\resources\views/user/education.blade.php ENDPATH**/ ?>