<?php $__env->startSection('title', 'Edit Profile'); ?>
<?php $__env->startSection('heading', 'Edit Profile'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-title">
                <h4>Edit Profile</h4>

            </div>
            <div class="card-body">
                <div class="basic-elements">
                    <form action="<?php echo e(route('Clients.update',$client->id)); ?>" method="POST">
                        <?php echo method_field("PUT"); ?>
                        <?php echo csrf_field(); ?>
                        <div class="row">


                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>First Name</label>
                                    <input type="text" class="form-control" value="<?php echo e($client->user->firstName); ?>" name="firstName">
                                </div>
                                <div class="form-group">
                                    <label>Last Name</label>
                                    <input type="text" class="form-control" value="<?php echo e($client->user->lastName); ?>" name="lastName">
                                </div>
                                <div class="form-group">
                                    <label>Email</label>
                                    <input id="email" class="form-control"value="<?php echo e($client->user->email); ?>" type="email" placeholder="Email" name="email">
                                </div>
                                <div class="form-group">
                                    <label>WC ID</label>
                                    <input id="wc_id " class="form-control"value="<?php echo e($client->wc_id); ?>" type="text" placeholder="WC Id" name="wc_id">
                                </div>
                                <div class="form-group">
                                    <label>Gender</label>
                                    <select class="form-control" name="gender">
                                        <?php
                                            $eduDropdown = App\Models\Dropdown::with('items')
                                                ->where('name', 'Gender')
                                                ->first();
                                        ?>
                                        <?php $__currentLoopData = $eduDropdown->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->item); ?>" <?php echo e(($client->gender==$row->item)?"selected":""); ?>><?php echo e($row->item); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Immegration Status</label>
                                    <select class="form-control" name="immigrationStatus">
                                        <?php
                                            $eduDropdown = App\Models\Dropdown::with('items')
                                                ->where('name', 'Immigration Status')
                                                ->first();
                                        ?>
                                        <?php $__currentLoopData = $eduDropdown->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->item); ?>" <?php echo e(($client->immigrationStatus==$row->item)?"selected":""); ?>><?php echo e($row->item); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Date of Birth</label>
                                    <input type="date" class="form-control" value="<?php echo e($client->dob); ?>" name="dob">
                                </div>
                                <div class="form-group">
                                    <label>Date of Assingment</label>
                                    <input type="date" class="form-control" value="<?php echo e($client->doa); ?>" name="doa">
                                </div>




                                <div class="form-group">
                                    <label>Englsh Proficiency</label>
                                    <select class="form-control" name="engProficiency">
                                        <?php
                                            $eduDropdown = App\Models\Dropdown::with('items')
                                                ->where('name', 'Language Proficiency')
                                                ->first();
                                        ?>
                                        <?php $__currentLoopData = $eduDropdown->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->item); ?>" <?php echo e(($client->engProficiency==$row->item)?"selected":""); ?>><?php echo e($row->item); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>Mother Tongue</label>
                                    <select class="form-control" name="motherTongue">

                                        <?php $__currentLoopData = App\Models\Language::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->language); ?>" <?php echo e(($client->motherTongue==$row->language)?"selected":""); ?>><?php echo e($row->language); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>

                                </div>
                            </div>
                            <div class="col-lg-6">

                                <div class="form-group">
                                    <label>Childcare Needed</label>&nbsp
                                    <div class="form-check-inline">

                                        <label class="form-check-label">
                                          <input type="radio" class="form-check-input" name="childcareNeeded" value="0" <?php echo e(($client->childcareNeeded==0)?"checked":""); ?>>No
                                        </label>
                                      </div>
                                      <div class="form-check-inline">
                                        <label class="form-check-label">
                                          <input type="radio" class="form-check-input" name="childcareNeeded" value="1" <?php echo e(($client->childcareNeeded==1)?"checked":""); ?>>Yes
                                        </label>
                                      </div>

                                </div>
                                <div class="form-group">
                                    <label>Interpreter Needed</label>&nbsp
                                    <div class="form-check-inline">

                                        <label class="form-check-label">
                                          <input type="radio" class="form-check-input" name="interpreterNeeded" value="0" <?php echo e(($client->interpreterNeeded==0)?"checked":""); ?>>No
                                        </label>
                                      </div>
                                      <div class="form-check-inline">
                                        <label class="form-check-label">
                                          <input type="radio" class="form-check-input" name="interpreterNeeded" value="1" <?php echo e(($client->interpreterNeeded==1)?"checked":""); ?>>Yes
                                        </label>
                                      </div>

                                </div>
                                <div class="form-group">
                                    <label>Interpreter Language</label>
                                    <select class="form-control" name="interpreterLanguage">

                                        <?php $__currentLoopData = App\Models\Language::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->language); ?>" <?php echo e(($client->interpreterLanguage==$row->language)?"selected":""); ?>><?php echo e($row->language); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>

                                </div>
                                <div class="form-group">
                                    <label>Primary Phone</label>
                                    <input type="text" class="form-control" value="<?php echo e($client->phonePrimary); ?>" name="phonePrimary">
                                </div>
                                <div class="form-group">
                                    <label>Secondary Phone</label>
                                    <input type="text" class="form-control" value="<?php echo e($client->phoneSecondary); ?>" name="phoneSecondary">
                                </div>
                                <div class="form-group">
                                    <label>City</label>
                                    <input type="text" class="form-control" value="<?php echo e($client->city); ?>" name="city">
                                </div>
                                <div class="form-group">
                                    <label>Province</label>
                                    <input type="text" class="form-control" value="<?php echo e($client->province); ?>" name="province">
                                </div>
                                <div class="form-group">
                                    <label>Country Origin</label>
                                    <input type="text" class="form-control" value="<?php echo e($client->countryOrigin); ?>" name="countryOrigin">
                                </div>
                                <div class="form-group">
                                    <label>Postal Code</label>
                                    <input type="text" class="form-control" value="<?php echo e($client->postalCode); ?>" name="postalCode">
                                </div>

                                <div class="form-group">
                                    <label>Street Address</label>
                                    <textarea class="form-control" rows="3"placeholder="Street Address..." name="streetAddress"><?php echo e($client->streetAddress); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label>Notes</label>
                                    <textarea class="form-control" rows="3"placeholder="Notes." name="notes"><?php echo e($client->notes); ?></textarea>
                                </div>
                                <div class="form-group float-right mt-4">
                                    <label>&nbsp</label>
                                    <button type="submit"  class="btn btn-success">Update</button>
                                 </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Client\resources\views/user/editprofile.blade.php ENDPATH**/ ?>