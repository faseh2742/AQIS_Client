<?php $__env->startSection('title', 'Document'); ?>
<?php $__env->startSection('heading', 'Document'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-title">
                    <h4>My Documents</h4>
                    <a href='#' class="btn btn-primary float-right" data-toggle="modal" data-target="#documentModel">Add
                        <i class="fa fa-plus"></i></a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Created</th>
                                    <th>Updated</th>
                                    <th>Added By</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td>
                                        <a href="<?php echo e(asset($document->doc_file)); ?>" class="btn btn-link" target="_blank"><?php echo e($document->doc_name); ?></a>
                                        </td>
                                        <td><?php echo e($document->created_at); ?></td>
                                        <td><?php echo e($document->updated_at); ?></td>
                                        <td><?php echo e($document->user->firstName); ?></td>


                                        <td>
                                            <div class="row float-right">

                                                <div class="col-sm-3">
                                                    <form id="deleteDocumentForm<?php echo e($document->id); ?>"
                                                        action="<?php echo e(route('Document.destroy', $document->id)); ?>"
                                                        method="POST" enctype="multipart/form-data">
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <button class="btn btn-danger btn-sm" type="button"
                                                            onclick="javascript:(confirm('Do you want to delete ?'))?
                                                document.getElementById('deleteDocumentForm<?php echo e($document->id); ?>').submit():'' "><i
                                                                class="fa fa-trash"></i></button>
                                                    </form>
                                                </div>
                                                <div class="col-sm-3">
                                                    <a href="javascript:;" class="btn btn-info btn-sm"
                                                        data-toggle="modal"
                                                        data-target="#documentModelEdit<?php echo e($document->id); ?>"><i
                                                            class="fa fa-edit"></i>
                                                    </a>
                                                </div>
                                             </div>




                                        </td>

                                    </tr>

                                    <div class="modal fade" id="documentModelEdit<?php echo e($document->id); ?>" tabindex="-1"
                                        role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                        <form action="<?php echo e(route('Document.update', $document->id)); ?>" method="POST" enctype="multipart/form-data">
                                            <?php echo method_field('PUT'); ?>
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-dialog modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalCenterTitle">Edit
                                                            <?php echo e($document->doc_name); ?></h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>

                                                    <div class="modal-body">

                                                        <div class="form-group">
                                                            <label>Document </label>
                                                            <select class="form-control" name="doc_name">
                                                                <?php
                                                                    $eduDropdown = App\Models\Dropdown::with('items')
                                                                        ->where('name', 'Clients Documents')
                                                                        ->first();
                                                                ?>
                                                                <?php $__currentLoopData = $eduDropdown->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($row->item); ?>" <?=( $document->doc_name==$row->item)?'selected':'';?>>
                                                                        <?php echo e($row->item); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                           <a href="#" class="btn btn-link"><?php echo e($document->doc_file); ?></a>


                                                        </div>
                                                        <div class="form-group">
                                                            <label>File</label>
                                                            <input type="file" class="form-control"
                                                            placeholder="File" name="doc_file"
                                                            value="<?php echo e($document->doc_file); ?>" required>

                                                        </div>




                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-success">Update</button>

                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade " id="documentModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Add Document</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('Document.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">

                        <div class="form-group">
                            <label>Document </label>
                            <select class="form-control" name="doc_name">
                                <?php
                                    $eduDropdown = App\Models\Dropdown::with('items')
                                        ->where('name', 'Clients Documents')
                                        ->first();
                                ?>
                                <?php $__currentLoopData = $eduDropdown->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->item); ?>">
                                        <?php echo e($row->item); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                        <div class="form-group">
                            <label>File</label>
                            <input type="file" class="form-control"
                            placeholder="File" name="doc_file"
                            required>

                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add</button>

                    </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Client\resources\views/user/document.blade.php ENDPATH**/ ?>