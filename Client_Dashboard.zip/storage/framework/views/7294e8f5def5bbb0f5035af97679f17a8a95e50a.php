<?php $__env->startSection('title', 'training'); ?>
<?php $__env->startSection('heading', 'training'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-title">
                    <h4>Trainings</h4>
                    <a href='#' class="btn btn-primary float-right" data-toggle="modal" data-target="#trainingModel">Add <i
                            class="fa fa-plus"></i></a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Training/ Certification / Professional Affiliation</th>
                                    <th>Association</th>
                                    <th>Year</th>
                                    <th>Country</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $myTrainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td><?php echo e($training->subject); ?></td>
                                        <td><?php echo e($training->association); ?></td>
                                        <td><?php echo e($training->training_year); ?></td>
                                        <td><?php echo e($training->country); ?></td>
                                        <td>
                                         <div class="row float-right">

                                            <div class="col-sm-6">   <form id="deletetrainingForm<?php echo e($training->id); ?>" action="<?php echo e(route('Training.destroy',$training->id)); ?>" method="POST">
                                                    <?php echo method_field("DELETE"); ?>
                                                    <?php echo csrf_field(); ?>
                                                <button class="btn btn-danger" type="button" onclick="javascript:(confirm('Do you want to delete ?'))?
                                                document.getElementById('deletetrainingForm<?php echo e($training->id); ?>').submit():''"><i class="fa fa-trash" ></i></button>
                                                </form>
                                            </div>
                                            <div class="col-sm-6">
                                                    <a href="javascript:;" class="btn btn-info" data-toggle="modal"
                                                    data-target="#trainingModelEdit<?php echo e($training->id); ?>"><i
                                                        class="fa fa-edit"></i>
                                                    </a>
                                            </div>

                                        </div>
                                    </td>

                                    </tr>

                                    <div class="modal fade" id="trainingModelEdit<?php echo e($training->id); ?>" tabindex="-1"
                                        role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                        <form action="<?php echo e(route('Training.update',$training->id)); ?>" method="POST">
                                            <?php echo method_field("PUT"); ?>
                                            <?php echo csrf_field(); ?>
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalCenterTitle">Edit <?php echo e($training->job_title); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>

                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <label>Subject</label>
                                                        <input type="text" name="subject" class="form-control" placeholder="Subject"
                                                            value="<?php echo e($training->subject); ?>" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Association</label>
                                                        <input type="hidden" name="id" value="<?php echo e($training->id); ?>">
                                                        <input type="text" class="form-control"
                                                        placeholder="Association" name="association"
                                                        value="<?php echo e($training->association); ?>" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Country</label>
                                                        <select class="form-control"  name="country">
                                                            <?php $__currentLoopData = App\Models\Country::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($row->name); ?>"
                                                                    <?php echo e(($row->name == $training->country) ? "selected":""); ?>>
                                                                    <?php echo e($row->name); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </select>
                                                    </div>

                                                    <div class="form-group">
                                                        <label>Training Year</label>
                                                        <input type="text" class="form-control"
                                                            placeholder="Training Year" name="training_year"
                                                            value="<?php echo e($training->training_year); ?>" required>
                                                    </div>



                                                </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-success">Update</button>

                                                    </div>
                                            </div>
                                        </div>
                                    </form>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade " id="trainingModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Add training</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('Training.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Subject</label>
                            <input type="text" name="subject" class="form-control" placeholder="Subject" required
                               >
                        </div>
                        <div class="form-group">
                            <label>Association</label>

                            <input type="text" class="form-control"
                            placeholder="Association" name="association" required
                           >
                        </div>
                        <div class="form-group">
                            <label>Country</label>
                            <select class="form-control"  name="country">
                                <?php $__currentLoopData = App\Models\Country::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->name); ?>"
                                      >
                                        <?php echo e($row->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>

                        <div class="form-group">
                            <label>Training Year</label>
                            <input type="text" class="form-control"
                                placeholder="Training Year" name="training_year" required
                               >
                        </div>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add</button>

                    </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Client\resources\views/user/training.blade.php ENDPATH**/ ?>