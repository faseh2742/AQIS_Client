<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('heading', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="user-profile">
                        <div class="row">

                            <div class="col-lg-12">
                                <div class="user-profile-name"><?php echo e($profile->firstName); ?> <?php echo e($profile->lastName); ?></div>

                                    <a href="<?php echo e(route('Clients.edit',$profile->client->id)); ?>" class="btn btn-info btn-sm float-right">Edit Profile <i class="fa fa-edit"></i></a>


                                <div class="user-Location">
                                    <i class="ti-location-pin"></i><?php echo e($profile->client->streetAddress); ?>

                                </div>
                                <div class="user-job-title">Client</div>

                                <div class="custom-tab user-profile-tab">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li role="presentation" class="active">
                                            <a href="#1" aria-controls="1" role="tab" data-toggle="tab">About</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content">
                                        <div role="tabpanel" class="tab-pane active" id="1">
                                            <div class="contact-information">
                                                <h4>Contact information</h4>
                                                <div class="email-content">
                                                    <span class="contact-title">Email:</span>
                                                    <span class="contact-email"><?php echo e($profile->email); ?></span>
                                                </div>
                                                <div class="phone-content">
                                                    <span class="contact-title">Primary Phone:</span>
                                                    <span class="phone-number"><?php echo e($profile->client->phonePrimary); ?></span>
                                                </div>
                                                <div class="website-content">
                                                    <span class="contact-title">Secondary Phone:</span>
                                                    <span class="contact-website"><?php echo e($profile->client->phoneSecondary); ?></span>
                                                </div>
                                                <div class="address-content">
                                                    <span class="contact-title">WC ID:</span>
                                                    <span class="mail-address"><?php echo e($profile->client->wc_id); ?></span>
                                                </div>
                                                <div class="address-content">
                                                    <span class="contact-title">City:</span>
                                                    <span class="mail-address"><?php echo e($profile->client->city); ?></span>
                                                </div>
                                                <div class="address-content">
                                                    <span class="contact-title">Country :</span>
                                                    <span class="mail-address"><?php echo e($profile->client->countryOrigin); ?></span>
                                                </div>
                                                <div class="address-content">
                                                    <span class="contact-title">Province:</span>
                                                    <span class="mail-address"><?php echo e($profile->client->province); ?></span>
                                                </div>
                                                <div class="address-content">
                                                    <span class="contact-title">Address:</span>
                                                    <span class="mail-address"><?php echo e($profile->client->streetAddress); ?></span>
                                                </div>



                                            </div>
                                            <div class="basic-information">
                                                <h4>Basic information</h4>
                                                <div class="birthday-content">
                                                    <span class="contact-title">Birthday:</span>
                                                    <span class="birth-date"> <?php echo e($profile->client->dob); ?> </span>
                                                </div>
                                                <div class="gender-content">
                                                    <span class="contact-title">Gender:</span>
                                                    <span class="gender"><?php echo e($profile->client->gender); ?></span>
                                                </div>
                                                <div class="birthday-content">
                                                    <span class="contact-title">Mother Tongue:</span>
                                                    <span class="birth-date"> <?php echo e($profile->client->motherTongue); ?> </span>
                                                </div>
                                                <div class="birthday-content">
                                                    <span class="contact-title">English Proficiency:</span>
                                                    <span class="birth-date"> <?php echo e($profile->client->engProficiency); ?> </span>
                                                </div>
                                                <div class="birthday-content">
                                                    <span class="contact-title">Immigration Status:</span>
                                                    <span class="birth-date"> <?php echo e($profile->client->immigrationStatus); ?> </span>
                                                </div>
                                                <div class="birthday-content">
                                                    <span class="contact-title">Interpreter Needed:</span>
                                                    <span class="birth-date"> <?php echo e(($profile->client->interpreterNeeded)?"Yes" :"NO"); ?> </span>
                                                </div>
                                                <div class="birthday-content">
                                                    <span class="contact-title">Childcare Needed:</span>
                                                    <span class="birth-date"> <?php echo e(($profile->client->childcareNeeded)? "Yes" :"NO"); ?> </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>




                                <div class="user-skill">
                                    <h4>Notes</h4>
                                    <ul>
                                        <li>
                                           <p>
                                            <?php echo e($profile->client->notes); ?>

                                           </p>
                                        </li>

                                    </ul>
                                </div>
                            </div>
                            
                                

                            
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Client\resources\views/user/profile.blade.php ENDPATH**/ ?>