<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/lib/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Styles -->
    
    <style>

        .form-handler{
            border-radius: 35px;
            box-shadow: inset 0px 0px 0px 4px hsl(0, 0%, 77%);
            background: rgb(255, 255, 255);
        }
        input[type=text]{
         border: 2px solid rgb(240, 236, 236);
          border-radius: 10px;
        }
        input[type=password]{
         border: 2px solid rgb(240, 236, 236);
          border-radius: 10px;
        }
        label{
          font-size: 16px;
          font-weight: bolder;
        }
        </style>
</head>
<body>


<div class="row border">
    <div class="col-md-12 border">
      <nav
        class="navbar navbar-expand-sm navbar-dark justify-content-around p-3"
      >
        <!-- Brand -->
        <a class="navbar-brand" href="#">Logo</a>
        <!-- Links -->
        <ul class="navbar-nav">
          <li class="nav-item p-2 pl-5">
            <a class="nav-link text-dark font-weight-bolder" href="#">Tours</a>
          </li>
          <li class="nav-item p-2 pl-5">
            <a class="nav-link text-dark font-weight-bolder" href="#"
              >Products</a
            >
          </li>
          <li class="nav-item p-2 pl-5">
            <a class="nav-link text-dark font-weight-bolder" href="#"
              >Pricing</a
            >
          </li>
          <li class="nav-item p-2 pl-5">
            <a class="nav-link text-dark font-weight-bolder" href="#"
              >Contacts</a
            >
          </li>
        </ul>
        <ul>

        

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto">
            <!-- Authentication Links -->
            <?php if(auth()->guard()->guest()): ?>
                <?php if(Route::has('login')): ?>
                    <li class="nav-item">
                        <a class="btn btn-default" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                    </li>
                <?php endif; ?>

                <?php if(Route::has('register')): ?>
                    <li class="nav-item">
                        <a class="btn btn-dark" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                    </li>
                <?php endif; ?>
            <?php else: ?>
                <li class="nav-item dropdown bg-dark">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?>

                    </a>

                    <div class="dropdown-menu dropdown-menu-end " aria-labelledby="navbarDropdown">
                        <a class="dropdown-item " href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            <?php endif; ?>
        </ul>
        </div>
      </nav>
    </div>

    <?php echo $__env->yieldContent('content'); ?>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</div>

</body>
<?php /**PATH E:\Client\resources\views/layouts/app.blade.php ENDPATH**/ ?>