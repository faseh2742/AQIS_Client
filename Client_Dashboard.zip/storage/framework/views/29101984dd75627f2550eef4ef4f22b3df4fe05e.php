<?php $__env->startSection('title', 'employeement'); ?>
<?php $__env->startSection('heading', 'employeement'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-title">
                    <h4>My employeements</h4>
                    <a href='#' class="btn btn-primary float-right" data-toggle="modal" data-target="#employeementModel">Add <i
                            class="fa fa-plus"></i></a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>NOC</th>
                                    <th>Job Title</th>
                                    <th>Years of Experience</th>
                                    <th>Country</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $myEmployeement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employeement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td><?php echo e($employeement->currentnoc->code); ?>-<?php echo e($employeement->currentnoc->title); ?></td>
                                        <td><?php echo e($employeement->job_title); ?></td>
                                        <td><?php echo e($employeement->experience_years); ?></td>
                                        <td><?php echo e($employeement->country); ?></td>
                                        <td>
                                         <div class="row float-right">

                                            <div class="col-sm-6">   <form id="deleteemployeementForm<?php echo e($employeement->id); ?>" action="<?php echo e(route('Employeement.destroy',$employeement->id)); ?>" method="POST">
                                                    <?php echo method_field("DELETE"); ?>
                                                    <?php echo csrf_field(); ?>
                                                <button class="btn btn-danger" type="button" onclick="javascript:(confirm('Do you want to delete ?'))?
                                                document.getElementById('deleteemployeementForm<?php echo e($employeement->id); ?>').submit():''"><i class="fa fa-trash" ></i></button>
                                                </form>
                                            </div>
                                            <div class="col-sm-6">
                                                    <a href="javascript:;" class="btn btn-info" data-toggle="modal"
                                                    data-target="#employeementModelEdit<?php echo e($employeement->id); ?>"><i
                                                        class="fa fa-edit"></i>
                                                    </a>
                                            </div>

                                        </div>
                                    </td>

                                    </tr>

                                    <div class="modal fade" id="employeementModelEdit<?php echo e($employeement->id); ?>" tabindex="-1"
                                        role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                        <form action="<?php echo e(route('Employeement.update',$employeement->id)); ?>" method="POST">
                                            <?php echo method_field("PUT"); ?>
                                            <?php echo csrf_field(); ?>
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalCenterTitle">Edit <?php echo e($employeement->job_title); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>

                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label>Job Title</label>
                                                            <input type="text" name="job_title" class="form-control" placeholder="Job Titlt"
                                                                value="<?php echo e($employeement->job_title); ?>" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>NOC</label>
                                                            <input type="hidden" name="id" value="<?php echo e($employeement->id); ?>">
                                                            <select class="form-control"  name="current_noc" >
                                                                <?php $__currentLoopData = App\Models\Noc::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($row->id); ?>" <?php echo e(($row->id == $employeement->currentnoc->id)?"selected":""); ?>><?php echo e($row->code); ?> <?php echo e($row->title); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Country</label>
                                                            <select class="form-control"  name="country">
                                                                <?php $__currentLoopData = App\Models\Country::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($row->name); ?>"
                                                                        <?php echo e(($row->name == $employeement->country) ? "selected":""); ?>>
                                                                        <?php echo e($row->name); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </select>
                                                        </div>

                                                        <div class="form-group">
                                                            <label>Year Of experience</label>
                                                            <input type="text" class="form-control"
                                                                placeholder="Years of Experience" name="experience_years"
                                                                value="<?php echo e($employeement->experience_years); ?>" required>
                                                        </div>



                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-success">Update</button>

                                                    </div>
                                            </div>
                                        </div>
                                    </form>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade " id="employeementModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Add employeement</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('Employeement.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Job Title</label>
                            <input type="text" name="job_title" class="form-control" placeholder="Job Title" required
                               >
                        </div>
                        <div class="form-group">
                            <label>NOC</label>
                            <select class="form-control"  name="current_noc">
                                <?php $__currentLoopData = App\Models\Noc::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->id); ?>" ><?php echo e($row->code); ?> <?php echo e($row->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                        <div class="form-group">
                            <label>Country</label>
                            <select class="form-control"  name="country">
                                <?php $__currentLoopData = App\Models\Country::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->name); ?>" ><?php echo e($row->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>

                        <div class="form-group">
                            <label>Year Of experience</label>
                            <input type="text" class="form-control"
                                placeholder="Years of Experience" name="experience_years" required
                              >
                        </div>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add</button>

                    </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Client\resources\views/user/employeement.blade.php ENDPATH**/ ?>